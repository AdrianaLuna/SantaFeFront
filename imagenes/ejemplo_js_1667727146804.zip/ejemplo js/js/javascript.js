

function cambiarfondo1() { document.body.style.backgroundColor = "red";}

function cambiarfondo2() {
  document.body.style.backgroundColor = "blue";
}

function cartel() {alert("Potrero Digital")}

function roberto() {
  document.getElementById("luis").innerHTML = "Roberto Carlos";
}


function AmpliarImg(x) {
  x.style.height = "20%";
  x.style.width = "20%";
}

function NormalImg(x) {
  x.style.height = "5%";
  x.style.width = "5%";
}
